<script lang="ts" setup>
import { promiseTimeout } from "@vueuse/core";
import { computed, ref, watch } from "vue";
import { Graph } from "../app/Graph";
import { isInParis } from "../geo";
import { getFixedPosition } from "../layout";
import {
  reachableStops,
  type SimpleJourney,
  type SimpleStop,
} from "../services/Wagon";
import AnimatedPath from "./AnimatedPath.vue";
import RotatingRing from "./RotatingRing.vue";
import StopName from "./StopName.vue";
import XMark from "./XMark.vue";

const props = defineProps<{
  journeys: SimpleJourney[];
  canAnimate: boolean;
  mode: "dynamic" | "atPlatform" | "noData";
}>();

const paths = ref<
  {
    points: { x: number; y: number }[];
    isAnimated: boolean;
    isInactive: boolean;
  }[]
>([]);

const terminusPaths = ref<
  {
    points: { x: number; y: number }[];
    isAnimated: boolean;
    isInactive: boolean;
  }[]
>([]);

const stops = computed<Graph<SimpleStop>>(() => {
  const graph = new Graph<SimpleStop>((x) => x.id);

  for (const journey of props.journeys) {
    graph.add(journey.stops);
  }

  return graph;
});
watch(
  () => stops.value.groupedTopologicalPaths,
  (groups) => {
    console.log(
      "🔥 DEMO FLOOR GROUPS:",
      groups.map((group, i) => ({
        group: i,
        floors: group.map((floor, floorIndex) => ({
          floor: floorIndex,
          stops: floor.map((stop) => stop.name),
        })),
      })),
    );
  },
  { immediate: true },
);

const skippedStops = computed(
  () => props.journeys.at(0)?.skippedStops || new Set<string>(),
);

const closedStops = computed(
  () => props.journeys.at(0)?.closedStops || new Set<string>(),
);

const stopsInParis = computed(() => {
  return props.journeys.at(0)?.stops.filter((stop) => isInParis(stop)) || [];
});

const someStopsOutOfScreen = ref(false);

function checkIfSomeStopsAreOutOfScreen() {
  for (const journey of props.journeys) {
    for (const stop of journey.stops) {
      const element = document.getElementById(stop.id);
      if (!element) {
        continue;
      }

      const { x, y } = getFixedPosition(element);

      if (x < 0 || x > window.innerWidth || y < 0 || y > window.innerHeight) {
        someStopsOutOfScreen.value = true;
        return;
      }
    }
  }

  someStopsOutOfScreen.value = false;
}

const nextDesservedStops = computed(() => {
  const stops = new Set<SimpleStop["id"]>();
  const journey = props.journeys.at(0);

  if (!journey) {
    return stops;
  }

  for (const stop of reachableStops(journey)) {
    stops.add(stop.id);
  }

  return stops;
});

// In compact mode, keep every stop from every displayed demo journey
// visible. The first journey still controls which stops are active; this
// set is only used to decide whether a label may be compacted/hidden.
const visibleStopIds = computed(() => {
  const ids = new Set<SimpleStop["id"]>();

  for (const journey of props.journeys) {
    for (const stop of reachableStops(journey)) {
      ids.add(stop.id);
    }
  }

  return ids;
});

const partialTerminusId = computed(() => {
  const journey = props.journeys.at(0);
  if (!journey) {
    return undefined;
  }

  const reachable = reachableStops(journey);
  if (reachable.at(-1)?.id === journey.stops.at(-1)?.id) {
    return undefined;
  }

  return reachable.at(-1)?.id;
});

const displayedTerminusId = computed(() => {
  const journey = props.journeys.at(0);

  if (!journey) {
    return undefined;
  }

  const destinationName = journey.userStopDeparture.destination.name;

  return journey.stops.find(
    (stop) => stop.name === destinationName,
  )?.id;
});

function isStopHidden(
  floor: SimpleStop[],
  i: number,
  stop: SimpleStop,
): boolean {
  if (someStopsOutOfScreen.value === false || props.mode === "noData") {
    return false;
  }

  return i !== floor.length - 1 && !visibleStopIds.value.has(stop.id);
}

const line = computed(() => props.journeys.at(0)?.line);

function meanLatitude(stops: SimpleStop[]): number {
  return stops.reduce((acc, stop) => acc + stop.position.lat, 0) / stops.length;
}

function northToSouth(a: SimpleStop[], b: SimpleStop[]): number {
  return meanLatitude(b) - meanLatitude(a);
}

function pointsForStops(stops: SimpleStop[]): { x: number; y: number }[] {
  return stops.flatMap((stop) => {
    const element = document.getElementById(stop.id);
    if (!element) {
      return { x: 0, y: 0 };
    }

    const visualBalancer = document.getElementById(
      `visual-balancer-${stop.id}`,
    );

    if (visualBalancer) {
      return [getFixedPosition(element), getFixedPosition(visualBalancer)];
    }

    return getFixedPosition(element);
  });
}

function updatePaths() {
  const _paths = [];
  const _terminusPaths = [];

  for (const journey of props.journeys) {
    const reachable = reachableStops(journey);

    const isDemo = journey.line.id === "demo-rer-a";

    // Find this journey's displayed terminus directly from its departure.
    const destinationName = journey.userStopDeparture.destination.name;

    const terminusIndex = isDemo
      ? reachable.findIndex((stop) => stop.name === destinationName)
      : -1;

    const activeStops =
      isDemo && terminusIndex >= 0
        ? reachable.slice(0, terminusIndex + 1)
        : reachable;

    // Active colored path
    if (activeStops.length >= 2) {
      _paths.push({
        points: pointsForStops(activeStops),
        isAnimated: true,
        isInactive: false,
      });
    }

    // Gray continuation after the displayed terminus
    const lastReachable = activeStops.at(-1);
    const lastStop = journey.stops.at(-1);

    if (lastReachable && lastStop && lastReachable.id !== lastStop.id) {
      const startIndex = journey.stops.findIndex(
        (stop) => stop.id === lastReachable.id,
      );

      if (startIndex >= 0) {
        _terminusPaths.push({
          points: pointsForStops(journey.stops.slice(startIndex)),
          isAnimated: false,
          isInactive: true,
        });
      }
    }
  }

  paths.value = _paths;
  terminusPaths.value = _terminusPaths;
}

const parisCirclePosition = ref({ xLeft: "0vh", xRight: "0vh", y: "0vh" });

function updateParisCirclePosition() {
  const firstParisStop =
    stopsInParis.value.at(0)
      ? document.getElementById(stopsInParis.value.at(0)!.id)
      : null;

  const lastParisStop =
    stopsInParis.value.at(1)
      ? document.getElementById(stopsInParis.value.at(1)!.id)
      : firstParisStop;

  function _getFixedPosition(element: HTMLElement | null) {
    if (!element) {
      return { x: 0, y: 0 };
    }

    return getFixedPosition(element);
  }

  const firstPosition =
    _getFixedPosition(firstParisStop);

  const lastPosition =
    _getFixedPosition(lastParisStop);

  parisCirclePosition.value = {
    // Push the left edge far enough left to contain
    // Gare de Lyon.
    xLeft:
      Math.max(0, firstPosition.x - 8 * 16) + "px",

    // Nation is the right edge of the Paris section.
    xRight:
      lastPosition.x + "px",

    // Keep the circle centered on the trunk.
    y:
      firstPosition.y + "px",
  };
}

function backgroundColor(stopId: string) {
  if (nextDesservedStops.value.values().next().value === stopId) {
    return "var(--title-color)";
  }

  if (
    displayedTerminusId.value === stopId &&
    props.mode !== "noData"
  ) {
    return "white";
  }
}

watch(
  () =>
    props.journeys
      .at(0)
      ?.stops.reduce((acc, stop) => acc + stop.position.lat, 0),
  async () => {
    await promiseTimeout(200);
    someStopsOutOfScreen.value = false;
    await promiseTimeout(200);
    checkIfSomeStopsAreOutOfScreen();
    await promiseTimeout(200);
    updateParisCirclePosition();
    await promiseTimeout(500);
    updatePaths();
  },
  { immediate: true },
);
</script>

<template>
  <div class="map-canvas">
    <div class="paths">
    <AnimatedPath
      :points="path.points"
      :color="line?.backgroundColor ?? '000000'"
      :is-animated="i === 0 && canAnimate"
      :is-inactive="false"
      :can-animate="canAnimate"
      :static="mode === 'atPlatform' && i === 0 && canAnimate"
      v-for="(path, i) in paths"
    ></AnimatedPath>
 <AnimatedPath
  :points="path.points"
  color="FCC2C2"
  :is-animated="false"
  :is-inactive="true"
  :can-animate="canAnimate"
  :static="true"
  v-for="path in terminusPaths"
/>
  </div>
    <div
      v-if="stopsInParis.length > 0"
    class="circle"
    :style="{
      '--top': parisCirclePosition.y,
      '--left': parisCirclePosition.xLeft,
      '--right': parisCirclePosition.xRight,
    }"
  >
    <span>Paris</span>
  </div>
    <div
      class="groups"
  :class="{
    compact: someStopsOutOfScreen,
    hidden: !canAnimate,
    static: mode === 'noData',
    demo: props.journeys.at(0)?.line?.id === 'demo-rer-a',
  }"
  :style="{ '--line-color': '#' + (line?.backgroundColor ?? '000000') }"
>
  <div
    class="floors"
    v-for="(group, i) in stops.groupedTopologicalPaths"
    :key="i"
    :class="`floor-group-${i}`"
  >
    <div
      class="floor"
      v-for="(floor, _) in group.sort(northToSouth)"
      :style="{
        gap: someStopsOutOfScreen ? '3vh' : 10 / group.length + 'vh',
      }"
      :class="{
        small: floor.length <= 3,
      }"
    >
        <div
          class="stop"
          v-for="(stop, k) in floor"
          :class="{
  active:
    nextDesservedStops.has(stop.id) && !skippedStops.has(stop.id),
  hidden: i === 0 && k === 0,
  origin: stop.id === nextDesservedStops.values().next().value,
  terminus: stop.id === displayedTerminusId,
  partialTerminus: stop.id === partialTerminusId,
  closed: closedStops.has(stop.id),
  appear: canAnimate,
  'demo-vincennes': stop.id === 'demo-vincennes',
}"
          :style="{
            '--animation-delay': `${
              nextDesservedStops.has(stop.id)
                ? [...nextDesservedStops.values()].indexOf(stop.id) *
                    (4.5 / nextDesservedStops.size) +
                  2.5
                : 11
            }s`,
            '--group-count': group.length,
            '--position': i,
          }"
        >
          <StopName
            :compact="isStopHidden(floor, k, stop)"
            class="label"
            :char-limit="20"
            :name="stop.name"
            :is-inactive="
              (!nextDesservedStops.has(stop.id) || skippedStops.has(stop.id)) &&
              mode !== 'noData'
            "
            :background-color="backgroundColor(stop.id)"
          ></StopName>
          <div class="anchor" :id="stop.id"></div>
          <div
            class="dot"
            :class="{
              animated: backgroundColor(stop.id) === 'var(--title-color)',
            }"
          >
            <RotatingRing v-if="stop.id === partialTerminusId" />
            <XMark v-if="closedStops.has(stop.id)" />
          </div>
        </div>
        <div class="stop" v-if="group.length > 1 && floor.length === 1">
          <StopName
            :name="group.at(0)?.at(-1)?.name || ''"
            :char-limit="20"
            :is-inactive="false"
            :compact="false"
          ></StopName>
          <div class="anchor" :id="'visual-balancer-' + floor.at(0)?.id"></div>
          <div class="dot"></div>
        </div>
      </div>
    </div>
    </div>
  </div>
</template>

<style scoped>

.map-canvas {
  position: relative;
  width: max-content;
  min-width: 100vw;
  min-height: 100vh;
}

.groups {
  position: relative;
  padding-top: 25vh;
  padding-left: 80px;
  padding-right: 80px;
  display: flex;
  gap: 0;
  height: 65vh;
  width: max-content;
  min-width: 100vw;
  max-width: none;
  box-sizing: border-box;
  justify-content: flex-start;
  z-index: 99;
}


.groups.hidden {
  opacity: 0;
}

.floors {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.floors:first-child {
  --path-gap: 0;
  padding-right: 0;
}

.floors:first-child .stop:last-child .anchor {
  transform: none;
}


.groups .floors:first-child {
  width: 550px;
  min-width: 550px;
}

.floors:last-child .floor {
  justify-content: flex-start;
}

.floor:only-child {
  margin: auto 0;
}

.floor.small:last-child:not(:only-child) {
  transform: translateY(-50%);
}

.floor {
  display: flex;
  justify-content: flex-start;
}



.stop {
  position: relative;
  opacity: 0;
}

.stop.appear {
  animation: stopAppear 2s ease-out var(--animation-delay) forwards;
}

@keyframes stopAppear {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

.stop.appear .label {
  animation: labelAppear 0.5s ease-out var(--animation-delay) forwards;
}

@keyframes labelAppear {
  from {
    scale: 1.3;
  }
  to {
    scale: 1;
  }
}

.stop:only-child {
  margin: auto 0;
}

.dot {
  position: relative;
  width: 4.5vh;
  height: 4.5vh;
  background-color: white;
  border-radius: 50%;
  transform: translate(-50%, -50%);
  z-index: 99;
}

.dot.animated {
  animation: dotBounce 1.6s infinite;
  box-shadow: 0 0 0 0.4vh var(--title-color);
}

@keyframes dotBounce {
  0% {
    transform: translate(-50%, -50%) scale(1.4);
  }
  50% {
    transform: translate(-50%, -50%) scale(1.6);
  }
  100% {
    transform: translate(-50%, -50%) scale(1.4);
  }
}

.groups:not(.static) .stop.active.terminus .dot {
  background-color: var(--line-color);
  box-shadow: 0 0 0 0.5vh var(--line-color);
}

.groups:not(.static) .stop.active.terminus.partialTerminus .dot {
  background-color: rgba(255, 255, 255, 0.438);
}

.groups:not(.static) .stop:not(.active).closed .dot {
  opacity: 1;
}

.stop.hidden:not(.active) {
  visibility: hidden;
}

.groups:not(.static) .stop:not(.active) .dot {
  opacity: 0.2;
}

.circle {
  position: absolute;
  display: grid;
  place-items: center;
  top: var(--top);
  left: calc(var(--left) - 4vh);
  right: calc(99vw - var(--right) - 4vh);
  height: calc(var(--right) - var(--left) + 30vh);
  transform: translateY(-45%) scale(1.3);
  background: linear-gradient(to bottom, #f0ebe9, #dcd7d6a6);
  border-radius: 9999px;
  z-index: -1;
}

.circle span {
  text-transform: uppercase;
  font-size: 5vh;
  margin-top: 34vh;
  color: var(--gray);
}
.groups > .floors:not(:first-child) {
  margin-left: 32px;
}
.groups.demo .floor-group-1 .floor:nth-child(1) {
  transform: translateY(-50px);
}

.groups.demo .floor-group-1 .floor:nth-child(2) {
  transform: translate(-35px, 10px);
}

/* Give the Gare de Lyon → Nation → Vincennes trunk more breathing room
   without moving the fork itself. */
.groups.demo .floor-group-0 .floor {
  gap: 5vh !important;
}

</style>
