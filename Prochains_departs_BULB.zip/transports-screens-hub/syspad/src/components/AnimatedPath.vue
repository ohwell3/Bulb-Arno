<script lang="ts" setup>
import { useTimeout, useWindowSize } from "@vueuse/core";
import { computed, ref, watch } from "vue";
import { Colors } from "../colors";

const props = defineProps<{
  points: { x: number; y: number }[];
  /** Color in HEX format without # */
  color: string;
  isAnimated: boolean;
  /** Path with gray background used when stops are not desserved */
  isInactive: boolean;
  /** Colored path without animation when no realtime data is available */
  static: boolean;
  canAnimate: boolean;
}>();

const { width, height } = useWindowSize();
const id = ref(window.crypto.randomUUID());

const { ready: firstAnimationFinished, start: startFirstAnimation } =
  useTimeout(7500, { controls: true });

const mainPath = ref<SVGPathElement | null>(null);

const pathLength = computed(() => {
  if (!mainPath.value) {
    return 0;
  }

  return mainPath.value.getTotalLength();
});

// The SVG must grow with the route so long imported/demo lines remain
// drawable inside the horizontal scroll area instead of being clipped at
// the viewport width.
const pathWidth = computed(() => {
  const maxX = props.points.reduce((max, point) => Math.max(max, point.x), 0);
  return Math.max(width.value, maxX + height.value * 8);
});

const path = computed(() => {
  const offsetX = height.value / 13.5;
  const d: string[] = [];

  console.table(
  props.points.map((p, i) => ({
    index: i,
    x: Math.round(p.x),
    y: Math.round(p.y),
    dx:
      i > 0
        ? Math.round(p.x - props.points[i - 1].x)
        : 0,
    dy:
      i > 0
        ? Math.round(p.y - props.points[i - 1].y)
        : 0,
  })),
);

  for (let i = 0; i < props.points.length; i++) {
    const point = props.points[i];
    const nextPoint = props.points[i + 1];

    if (i === 0) {
      d.push(`M ${point.x} ${point.y}`);
    }

    if (!nextPoint) continue;

    // Normal horizontal section
    if (nextPoint.y === point.y) {
      d.push(`L ${nextPoint.x} ${nextPoint.y}`);
      continue;
    }

    // Branch: short horizontal lead, then a shallow diagonal
    const dx = nextPoint.x - point.x;

    // Keep the diagonal shallow instead of making a huge slash
    const lead = Math.min(offsetX, dx * 0.35);

    d.push(`L ${point.x + lead} ${point.y}`);

    // Shallow diagonal
    d.push(
      `L ${nextPoint.x - lead} ${nextPoint.y}`,
    );

    // Finish at the station
    d.push(`L ${nextPoint.x} ${nextPoint.y}`);
  }

  console.log(`[AnimatedPath ${id.value}] SVG PATH:`, d.join(" "));

  return d.join(" ");
});

const primaryColor = computed(() => `#${props.color}`);

const secondaryColor = computed(() => {
  return Colors.mix(primaryColor.value, "FFFFFF", 0.5);
});

const tertiaryColor = computed(() => {
  return Colors.mix(primaryColor.value, "FFFFFF", 0.75);
});

watch(
  () => props.canAnimate,
  (canAnimate) => {
    if (canAnimate) {
      startFirstAnimation();
    }
  }
);
</script>

<template>
  <svg
    :class="{ animated: isAnimated && !static }"
    :width="pathWidth"
    :height="height"
    :style="{ zIndex: props.isAnimated ? 3 : 0, '--path-length': pathLength }"
  >
    <path
      :d="path"
      fill="none"
      :stroke="isAnimated || static ? primaryColor : tertiaryColor"
      stroke-width="6vh"
      stroke-linecap="round"
      stroke-linejoin="round"
      ref="mainPath"
    ></path>
  </svg>

  <svg
    v-if="isAnimated && !firstAnimationFinished && !static"
    :width="pathWidth"
    :height="height"
    style="z-index: 2"
  >
    <path
      :d="path"
      fill="none"
      :stroke="tertiaryColor"
      stroke-width="6vh"
      stroke-linecap="round"
      stroke-linejoin="round"
      ref="mainPath"
    ></path>
  </svg>

  <svg
    v-if="isAnimated && firstAnimationFinished && !static"
    class="gradient"
    :width="pathWidth"
    :height="height"
    xmlns="http://www.w3.org/2000/svg"
    :viewBox="`0 0 ${pathWidth} ${height}`"
    fill="none"
  >
    <defs>
      <linearGradient :id="id" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop :stop-color="secondaryColor" offset="0%" />
        <stop :stop-color="primaryColor" offset="100%" />
      </linearGradient>
    </defs>
    <path
      :d="path"
      :stroke="`url(#${id})`"
      stroke-width="6vh"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>

  <svg
    v-if="isAnimated && firstAnimationFinished && !static"
    class="gradientBackground"
    :width="pathWidth"
    :height="height"
    xmlns="http://www.w3.org/2000/svg"
    :viewBox="`0 0 ${pathWidth} ${height}`"
    fill="none"
  >
    <path
      :d="path"
      :stroke="secondaryColor"
      stroke-width="6vh"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>

<style scoped>
svg {
  position: absolute;
  top: 0;
  left: 0;
}

svg.animated path {
  stroke-dasharray: var(--path-length);
  stroke-dashoffset: var(--path-length);
  animation: draw 10s linear infinite;
}

@keyframes draw {
  0% {
    opacity: 1;
    stroke-dashoffset: var(--path-length);
  }

  75% {
    opacity: 1;
    stroke-dashoffset: 0;
  }

  100% {
    opacity: 0;
    stroke-dashoffset: 0;
  }
}

svg.gradient {
  z-index: 2;
}

svg.gradientBackground {
  z-index: 1;
}

svg.gradient path {
  animation: fadeOut 10s linear 2.5s infinite;
}

@keyframes fadeOut {
  0% {
    opacity: 1;
  }
  75% {
    opacity: 0;
  }
}
</style>
