<script setup lang="ts">
import { computed, ref } from "vue";
import { parseBulbJson } from "../importers/bulb/parser";
import { bulbToSyspad, type ImportedBundle } from "../importers/bulb/toSyspad";

type ImportedEntry = { raw: ReturnType<typeof parseBulbJson>; bundle: ImportedBundle; stationId: string };
const emit = defineEmits<{ load: [bundle: ImportedBundle] }>();
const imported = ref<ImportedEntry[]>([]);
const error = ref("");

async function importFile(event: Event) {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;
  error.value = "";
  try {
    const raw = parseBulbJson(JSON.parse(await file.text()));
    const firstStation = raw.paths.flatMap((path) => path)[0] ?? [...raw.stops.values()][0];
    if (!firstStation) throw new Error("No stations were found in the Bulb topology.");
    const bundle = bulbToSyspad(raw, firstStation.id);
    const entry: ImportedEntry = { raw, bundle, stationId: firstStation.id };
    const existing = imported.value.findIndex((item) => item.raw.id === raw.id);
    if (existing >= 0) imported.value.splice(existing, 1, entry);
    else imported.value.push(entry);
    emit("load", bundle);
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : "Could not import this Bulb JSON.";
  } finally { input.value = ""; }
}

const stationOptions = (entry: ImportedEntry) => entry.bundle.stops;
function selectStation(entry: ImportedEntry, stationId: string) {
  entry.stationId = stationId;
  try {
    entry.bundle = bulbToSyspad(entry.raw, stationId);
    emit("load", entry.bundle);
    error.value = "";
  } catch (cause) {
    error.value = cause instanceof Error ? cause.message : "Could not generate paths from this station.";
  }
}

function load(entry: ImportedEntry) { emit("load", entry.bundle); }
const entryLabels = computed(() => imported.value.map((entry) => ({ id: entry.raw.id, label: entry.bundle.line.number ? `${entry.bundle.line.mode} ${entry.bundle.line.number}` : entry.bundle.line.mode })));
</script>

<template>
  <div class="bulb-importer">
    <label class="import-button">Import Bulb JSON<input type="file" accept="application/json,.json" @change="importFile" /></label>

    <div v-for="entry in imported" :key="entry.raw.id" class="line-entry">
      <span class="line-label" :style="{ '--line-color': '#' + entry.bundle.line.backgroundColor }">{{ entry.bundle.line.number ? `${entry.bundle.line.mode} ${entry.bundle.line.number}` : entry.bundle.line.mode }}</span>
      <select :value="entry.stationId" @change="selectStation(entry, ($event.target as HTMLSelectElement).value)" :aria-label="`Displayed station for ${entry.bundle.line.mode} ${entry.bundle.line.number}`">
        <option v-for="stop in stationOptions(entry)" :key="stop.id" :value="stop.id">{{ stop.name }}</option>
      </select>
      <button class="load-button" @click="load(entry)">Display</button>
    </div>

    <span v-if="error" class="error">{{ error }}</span>
  </div>
</template>

<style scoped>
.bulb-importer { position: fixed; top: 1.5vh; left: 34vh; z-index: 10000; display: flex; align-items: center; gap: .8vh; padding: .8vh; border-radius: 1vh; background: rgba(255,255,255,.92); box-shadow: 0 .4vh 1.5vh rgba(0,0,0,.14); font-family: Parisine,sans-serif; max-width: calc(100vw - 38vh); overflow-x: auto; }
.import-button,.load-button,.line-label,select { border: 0; border-radius: .7vh; padding: .8vh 1.2vh; font: inherit; font-weight: 700; }
.import-button { background:#202020;color:white; cursor:pointer; white-space:nowrap; }
.import-button input { display:none; }
.line-entry { display:flex;align-items:center;gap:.5vh;flex:0 0 auto; }
.line-label { background:var(--line-color);color:white;white-space:nowrap; }
select { background:white; border:1px solid #ccc; min-width:20vh; max-width:32vh; }
.load-button { background:#444;color:white;cursor:pointer;white-space:nowrap; }
.error { max-width:35vh;color:#b00020;font-size:1.7vh; }
</style>
