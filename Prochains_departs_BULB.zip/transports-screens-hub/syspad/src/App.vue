<script setup lang="ts">
import { computedAsync, promiseTimeout, useTimeout } from "@vueuse/core";
import { Dayjs } from "dayjs";
import { computed, onMounted, ref, watch } from "vue";
import Header from "./components/Header.vue";
import MiniETA from "./components/MiniETA.vue";
import BulbImporter from "./components/BulbImporter.vue";
import type { ImportedBundle } from "./importers/bulb/toSyspad";
import { setActiveBulbBundle } from "./importers/bulb/runtime";
import OfflineHeader from "./components/OfflineHeader.vue";
import RepairScreen from "./components/RepairScreen.vue";
import ShortTrainBubble from "./components/ShortTrainBubble.vue";
import Stops from "./components/Stops.vue";
import Time from "./components/Time.vue";
import { useArrivingStatus } from "./composables/useArrivingStatus";
import { useJourneys } from "./composables/useJourneys";
import { extractNextUniqueDepartures } from "./journeys";
import { getFixedPosition } from "./layout";
import { type SimpleDeparture } from "./services/Wagon";
import type { ApplicationParams } from "./types";

interface MiniETAPosition {
  x: number;
  y: number;
  eta: Dayjs;
}

const params = ref<ApplicationParams>(null);
const importedLine = ref<ImportedBundle | null>(null);
const nextDeparture = ref<SimpleDeparture | undefined>(undefined);
const { journeys, nextDepartureIsInPast } = useJourneys(params);

const miniETAs = computedAsync<MiniETAPosition[]>(async () => {
  if (!journeys.value) return [];
  const departures = extractNextUniqueDepartures(journeys.value);
  await promiseTimeout(10000);
  console.log(departures);
  return departures.map((departure) => {
    const anchor = document.getElementById(departure.terminusId);
    console.log(anchor);
    if (!anchor) {
      return {
        x: -999,
        y: -999,
        eta: departure.eta,
      };
    }
    const { x, y } = getFixedPosition(anchor);
    return {
      x,
      y,
      eta: departure.eta,
    };
  });
}, []);

const lineLogo = computed(() => {
  if (importedLine.value) {
    const line = importedLine.value.line;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
      <rect x="-10" y="-5" width="100" height="100" rx="26" fill="#${line.backgroundColor}" />
      <text x="45" y="70" text-anchor="middle" font-size="68" font-family="Parisine" font-weight="bold" fill="#ffffff">${line.number}</text>
    </svg>`;
  }

  if (new URLSearchParams(window.location.search).has("demo")) {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
      <rect
        x="-10"
        y="-5"
        width="100"
        height="100"
        rx="26"
        fill="#ed1c2a"
      />
      <text
        x="45"
        y="70"
        text-anchor="middle"
        font-size="68"
        font-family="Parisine"
        font-weight="bold"
        fill="#ffffff"
      >A</text>
    </svg>`;
  }

  return journeys.value?.at(0)?.line.numberShapeSvg;
});
const terminusName = computed(() => {
  const journey = journeys.value?.at(0);

  if (!journey) {
    return undefined;
  }

  return journey.userStopDeparture.destination.name;
});
const { ready: canAnimate, start: preventAnimation } = useTimeout(4000, {
  controls: true,
});

const { status, remainingMinutes } = useArrivingStatus(nextDeparture);

function loadImportedLine(bundle: ImportedBundle) {
  importedLine.value = bundle;
  setActiveBulbBundle(bundle);
  params.value = {
    currentStopId: bundle.originId,
    lineId: bundle.line.id,
    terminusPosition: undefined,
  };
}

onMounted(async () => {
  setTimeout(
    () => {
      window.location.reload();
    },
    1000 * 60 * 60 * 18,
  );

  const urlParams = new URLSearchParams(window.location.search);
  const terminusPosition = urlParams.get("to")?.split(",").map(parseFloat);

  params.value = {
    currentStopId: urlParams.get("from") ?? "",
    lineId: urlParams.get("route") ?? "",
    terminusPosition: terminusPosition
      ? { lat: terminusPosition[0], lon: terminusPosition[1] }
      : undefined,
    shortTrainMessage: urlParams.get("shortTrainMessage") ?? undefined,
  };
});

watch(
  () => journeys.value?.at(0)?.stops.reduce((acc, stop) => acc + stop.id, ""),
  async () => {
    preventAnimation();
    await promiseTimeout(1500);
    nextDeparture.value = journeys.value?.at(0)?.userStopDeparture;
  },
);
</script>

<template>
  <BulbImporter @load="loadImportedLine" />
  <template v-if="lineLogo">
    <Time class="time"></Time>
    <div class="logo" v-html="lineLogo"></div>
    <template v-if="nextDeparture">
      <OfflineHeader
        v-if="nextDepartureIsInPast"
        class="header"
      ></OfflineHeader>
      <Header
        v-else
        :can-animate="canAnimate"
        class="header"
        :departure="nextDeparture"
        :remaining-minutes="remainingMinutes"
        :position="status"
        :terminus-name="terminusName"
      ></Header>
      <div class="map-scroll" v-if="journeys">
        <Stops
          :can-animate="canAnimate"
          :mode="
            nextDepartureIsInPast
              ? 'noData'
              : status === 'atPlatform'
                ? 'atPlatform'
                : 'dynamic'
          "
          :journeys="journeys"
        ></Stops>
      </div>
      <ShortTrainBubble
        v-if="
          nextDeparture.vehicleLength === 'SHORT' &&
          ['left', 'right'].includes(params?.shortTrainMessage ?? '')
        "
        :walk-to="params?.shortTrainMessage === 'right' ? 'right' : 'left'"
        class="shortTrainBubble"
        :class="params?.shortTrainMessage"
      ></ShortTrainBubble>
      <MiniETA
        :style="{
          position: 'absolute',
          top: `${miniETA.y}px`,
          left: `${miniETA.x}px`,
        }"
        v-for="miniETA in miniETAs"
        v-show="canAnimate"
        :key="miniETA.x + miniETA.y"
        :eta="miniETA.eta"
      ></MiniETA>
    </template>
  </template>
  <RepairScreen v-else></RepairScreen>
</template>

<style scoped>
.time {
  position: fixed;
  top: 0;
  right: 0;
  z-index: 9999;
}

.map-scroll {
  position: fixed;
  inset: 0;
  width: 100vw;
  height: 100vh;
  overflow-x: auto;
  overflow-y: hidden;
  overscroll-behavior-x: contain;
  scrollbar-gutter: stable;
}

.header {
  position: fixed;
  top: 7vh;
  left: 27vh;
  z-index: 999;
}

.logo {
  position: fixed;
  top: 2vh;
  left: 2vh;
  width: 30vh;
  height: 30vh;
  z-index: 9999;
}
.shortTrainBubble {
  position: fixed;
  top: -20vh;
  z-index: 999;
}

.shortTrainBubble.right {
  left: 20vh;
}

.shortTrainBubble.left {
  right: 20vh;
}
</style>
