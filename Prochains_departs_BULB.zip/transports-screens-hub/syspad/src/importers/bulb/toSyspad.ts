import dayjs from "dayjs";
import type { SimpleConnection, SimpleJourney, SimpleLine, SimpleStop } from "../../services/Wagon";
import type { ImportedLine, ImportedStop } from "./types";

export type ImportedBundle = {
  line: SimpleLine;
  journeys: SimpleJourney[];
  connections: Map<string, ImportedStop["connections"]>;
  originId: string;
  stops: ImportedStop[];
  paths: ImportedStop[][];
};

function makeSimpleLine(line: ImportedLine): SimpleLine {
  return { id: line.id, number: line.index, backgroundColor: line.color, textColor: "ffffff", importance: 1 };
}

function makeStops(line: ImportedLine, simpleLine: SimpleLine): Map<string, SimpleStop> {
  return new Map([...line.stops.values()].map((stop) => [stop.id, {
    id: stop.id, name: stop.name, position: stop.position, lines: [simpleLine],
    subtitle: stop.subtitle, interestPoint: stop.interestPoint, accessible: stop.accessible,
    connections: stop.connections as SimpleConnection[],
  }]));
}

function uniquePaths(paths: ImportedStop[][]): ImportedStop[][] {
  const seen = new Set<string>();
  return paths.filter((path) => {
    const key = path.map((stop) => stop.id).join(">>");
    if (seen.has(key)) return false;
    seen.add(key);
    return path.length > 0;
  });
}

function findOrigin(line: ImportedLine): ImportedStop {
  const firstTerminus = line.paths.flat().find((stop) => stop.terminus);
  return firstTerminus ?? line.paths.at(0)?.at(0) ?? [...line.stops.values()][0];
}

export function bulbToSyspad(line: ImportedLine, originId?: string): ImportedBundle {
  const simpleLine = makeSimpleLine(line);
  const simpleStops = makeStops(line, simpleLine);
  const origin = originId ? line.stops.get(originId) : findOrigin(line);
  if (!origin) throw new Error("The selected station does not exist in this Bulb line.");

  const paths = uniquePaths(line.paths);
  const journeys: SimpleJourney[] = [];

  for (const [index, path] of paths.entries()) {
    const start = path.findIndex((stop) => stop.id === origin.id);
    if (start < 0) continue;

    const route = path.slice(start).map((stop) => simpleStops.get(stop.id)).filter(Boolean) as SimpleStop[];
    if (route.length === 0) continue;

    const destination = [...route].reverse().find((stop) => stop.id && line.stops.get(stop.id)?.terminus) ?? route.at(-1)!;
    const departureId = `${line.id}-import-${index}`;
    const leavesAt = dayjs().add(2 + journeys.length * 2, "minute");

    journeys.push({
      id: departureId,
      line: simpleLine,
      userStopDeparture: {
        id: departureId,
        destination: { name: destination.name, averagePosition: destination.position },
        leavesAt, arrivesAt: leavesAt, journeyCode: departureId, vehicleLength: "LONG",
      },
      stops: route,
      closedStops: new Set(route.filter((stop) => line.stops.get(stop.id)?.closed).map((stop) => stop.id)),
      skippedStops: new Set(),
    });
  }

  if (journeys.length === 0) {
    throw new Error(`No route reaches the selected station (${origin.name}).`);
  }

  return {
    line: simpleLine, journeys,
    connections: new Map([...line.stops.values()].map((stop) => [stop.id, stop.connections])),
    originId: origin.id,
    stops: [...line.stops.values()].sort((a, b) => a.name.localeCompare(b.name, "fr")),
    paths,
  };
}
