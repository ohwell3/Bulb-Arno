import type { BulbConnection, ImportedLine, ImportedStop } from './types';

const asObject = (value: unknown): Record<string, any> | null =>
  value && typeof value === 'object' ? (value as Record<string, any>) : null;

const lineIndex = (value: any): string =>
  value?.mode === undefined
    ? String(value?.$builtinLineIndex?.index ?? '')
    : String(value?.$builtinLineIndex?.index ?? '');

function readConnections(stop: any): BulbConnection[] {
  if (!Array.isArray(stop?.connections)) return [];

  return stop.connections.flatMap((connection: any) => {
    const modeConnection = connection?.$modeConnection;
    if (modeConnection) {
      return [{
        mode: String(modeConnection.mode ?? ''),
        lines: Array.isArray(modeConnection.elements)
          ? modeConnection.elements.flatMap((element: any) => {
              const value = element?.$modeConnectionElement?.lineIndex;
              if (!value) return [];
              return [{ mode: String(value.mode ?? modeConnection.mode ?? ''), index: lineIndex(value) }];
            })
          : [],
        walk: Boolean(modeConnection.walk),
      }];
    }

    const serviceConnection = connection?.$serviceConnection;
    if (serviceConnection) {
      const services = Array.isArray(serviceConnection.elements)
        ? serviceConnection.elements
            .map((element: any) => element?.$serviceConnectionElement?.service)
            .filter(Boolean)
        : [];
      return services.length
        ? [{ mode: 'SERVICE', lines: [], walk: Boolean(serviceConnection.walk), service: services.join(',') }]
        : [];
    }

    return [];
  });
}

function makeStop(raw: any): ImportedStop | null {
  const stop = raw?.$stop;
  if (!stop?.name) return null;

  const id = String(raw.id ?? `bulb-stop-${String(stop.name).toLocaleLowerCase().replace(/[^a-z0-9]+/gi, '-')}`);

  return {
    id,
    name: String(stop.name).replace(/\s*\n\s*/g, ' '),
    subtitle: stop.subtitle ? String(stop.subtitle) : undefined,
    placeName: stop.placeName ? String(stop.placeName) : undefined,
    interestPoint: Boolean(stop.interestPoint),
    closed: Boolean(stop.closed),
    terminus: Boolean(stop.terminus),
    accessible: typeof stop.accessible === 'boolean' ? stop.accessible : undefined,
    connections: readConnections(stop),
    // Bulb exports the visual topology, not geographic coordinates. The
    // renderer needs coordinates, so we create a stable schematic layout.
    position: {
      // Bulb's topology is schematic. Keep imported stations in the Paris
      // viewport so Syspad can apply its normal Paris background treatment.
      lat: 48.85,
      long: 2.35,
    },
  };
}

function readElement(element: any): ImportedStop[][] {
  const object = asObject(element);
  if (!object) return [];

  if (object.$stop) {
    const stop = makeStop(object);
    return stop ? [[stop]] : [];
  }

  if (object.$branch || object.$lineSection) {
    const elements = object.$branch?.elements ?? object.$lineSection?.elements ?? [];
    return readSequence(elements);
  }

  if (object.$parallelBranches) {
    return (object.$parallelBranches.sections ?? []).flatMap((section: any) =>
      readElement(section),
    );
  }

  return [];
}

function readSequence(elements: any[]): ImportedStop[][] {
  let paths: ImportedStop[][] = [[]];

  for (const element of elements) {
    const alternatives = readElement(element);
    if (alternatives.length === 0) continue;

    const next: ImportedStop[][] = [];
    for (const prefix of paths) {
      for (const suffix of alternatives) {
        const merged = [...prefix];
        for (const stop of suffix) {
          if (merged.at(-1)?.id !== stop.id) merged.push(stop);
        }
        next.push(merged);
      }
    }
    paths = next;
  }

  return paths.filter((path) => path.length > 0);
}

function collectPaths(topology: any[]): ImportedStop[][] {
  return readSequence(topology);
}

export function parseBulbJson(input: unknown): ImportedLine {
  const root = asObject(input);
  const line = root?.line;
  if (!line) throw new Error('This file does not contain a Bulb line.');

  const mode = String(line.mode ?? '');
  const index = String(line.index?.$builtinLineIndex?.index ?? '');
  if (!mode || !index) throw new Error('Bulb line is missing its mode or index.');

  const paths = collectPaths(Array.isArray(line.topology) ? line.topology : []);
  if (paths.length === 0) throw new Error('No stops were found in the Bulb topology.');

  const stops = new Map<string, ImportedStop>();
  for (const path of paths) {
    for (const stop of path) stops.set(stop.id, stop);
  }

  return {
    id: `bulb-${mode.toLowerCase()}-${index.toLowerCase()}`,
    mode,
    index,
    color: String(line.color ?? '#000000').replace('#', ''),
    stops,
    paths: paths.filter((path, index, all) => {
      const key = path.map((stop) => stop.id).join('>');
      return all.findIndex((candidate) => candidate.map((stop) => stop.id).join('>') === key) === index;
    }),
  };
}
