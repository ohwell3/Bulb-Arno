export type BulbConnection = {
  mode: string;
  lines: { mode: string; index: string }[];
  walk: boolean;
  service?: string;
};

export type ImportedStop = {
  id: string;
  name: string;
  subtitle?: string;
  placeName?: string;
  interestPoint: boolean;
  closed: boolean;
  terminus: boolean;
  accessible?: boolean;
  connections: BulbConnection[];
  position: { lat: number; long: number };
};

export type ImportedLine = {
  id: string;
  mode: string;
  index: string;
  color: string;
  stops: Map<string, ImportedStop>;
  paths: ImportedStop[][];
};
