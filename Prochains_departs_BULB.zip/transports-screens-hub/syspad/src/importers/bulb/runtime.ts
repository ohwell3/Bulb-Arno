import type { ImportedBundle } from './toSyspad';

let activeBundle: ImportedBundle | null = null;

export function setActiveBulbBundle(bundle: ImportedBundle | null) {
  activeBundle = bundle;
}

export function getActiveBulbBundle() {
  return activeBundle;
}
