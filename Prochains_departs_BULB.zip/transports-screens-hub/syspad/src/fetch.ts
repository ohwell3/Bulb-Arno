import dayjs from "dayjs";

import { firstUnique } from "./app/utils";
import { nearest, type Point } from "./geo";

import {
  Wagon,
  type SimpleDeparture,
  type SimpleJourney,
  type SimpleStop,
} from "./services/Wagon";
import { getActiveBulbBundle } from "./importers/bulb/runtime";

// ============================================================
// DEMO MODE
// ============================================================

const isDemoMode = () =>
  new URLSearchParams(window.location.search).has("demo");

const demoLine = {
  id: "demo-rer-a",
  number: "A",
  backgroundColor: "e2231a",
  textColor: "ffffff",
  importance: 1,
};

const demoTrunkStops: SimpleStop[] = [
  {
    id: "demo-gare-de-lyon",
    name: "Gare de Lyon",
    position: { lat: 48.8443, long: 2.3730 },
    lines: [demoLine],
  },
  {
    id: "demo-nation",
    name: "Nation",
    position: { lat: 48.8484, long: 2.3959 },
    lines: [demoLine],
  },
  {
    id: "demo-vincennes",
    name: "Vincennes",
    position: { lat: 48.8475, long: 2.4338 },
    lines: [demoLine],
  },
];

const demoUpperBranch: SimpleStop[] = [
  {
    id: "demo-val-de-fontenay",
    name: "Val de Fontenay",
    position: { lat: 48.8547, long: 2.4757 },
    lines: [demoLine],
  },
  {
    id: "demo-neuilly-plaisance",
    name: "Neuilly-Plaisance",
    position: { lat: 48.8530, long: 2.5145 },
    lines: [demoLine],
  },
  {
    id: "demo-bry-sur-marne",
    name: "Bry-sur-Marne",
    position: { lat: 48.8445, long: 2.5240 },
    lines: [demoLine],
  },
  {
    id: "demo-noisy-le-grand-mont-d-est",
    name: "Noisy-le-Grand–Mont d'Est",
    position: { lat: 48.8387, long: 2.5520 },
    lines: [demoLine],
  },
  {
    id: "demo-noisy-champs",
    name: "Noisy-Champs",
    position: { lat: 48.8408, long: 2.5785 },
    lines: [demoLine],
  },
  {
    id: "demo-noisiel",
    name: "Noisiel",
    position: { lat: 48.8480, long: 2.6270 },
    lines: [demoLine],
  },
  {
    id: "demo-lognes",
    name: "Lognes",
    position: { lat: 48.8375, long: 2.6355 },
    lines: [demoLine],
  },
  {
    id: "demo-torcy",
    name: "Torcy",
    position: { lat: 48.8395, long: 2.6550 },
    lines: [demoLine],
  },
  {
    id: "demo-bussy-saint-georges",
    name: "Bussy-Saint-Georges",
    position: { lat: 48.8385, long: 2.7060 },
    lines: [demoLine],
  },
  {
    id: "demo-val-deurope",
    name: "Val d'Europe",
    position: { lat: 48.8540, long: 2.7750 },
    lines: [demoLine],
  },
  {
    id: "demo-marne-la-vallee-chessy",
    name: "Marne-la-Vallée–Chessy",
    position: { lat: 48.8690, long: 2.7820 },
    lines: [demoLine],
  },
];

const demoSouthernBranch: SimpleStop[] = [
  {
    id: "demo-fontenay-sous-bois",
    name: "Fontenay-sous-Bois",
    position: { lat: 48.8545, long: 2.4820 },
    lines: [demoLine],
  },
  {
    id: "demo-nogent-sur-marne",
    name: "Nogent-sur-Marne",
    position: { lat: 48.8335, long: 2.4820 },
    lines: [demoLine],
  },
  {
    id: "demo-joinville-le-pont",
    name: "Joinville-le-Pont",
    position: { lat: 48.8190, long: 2.4680 },
    lines: [demoLine],
  },
  {
    id: "demo-saint-maur-creteil",
    name: "Saint-Maur–Créteil",
    position: { lat: 48.8060, long: 2.4700 },
    lines: [demoLine],
  },
  {
    id: "demo-le-parc-de-saint-maur",
    name: "Le Parc de Saint-Maur",
    position: { lat: 48.7990, long: 2.4800 },
    lines: [demoLine],
  },
  {
    id: "demo-champigny",
    name: "Champigny",
    position: { lat: 48.8130, long: 2.5110 },
    lines: [demoLine],
  },
  {
    id: "demo-la-varenne",
    name: "La Varenne",
    position: { lat: 48.7920, long: 2.5160 },
    lines: [demoLine],
  },
  {
    id: "demo-chennevieres",
    name: "Chennevières",
    position: { lat: 48.7910, long: 2.5370 },
    lines: [demoLine],
  },
  {
    id: "demo-sucy-bonneuil",
    name: "Sucy-Bonneuil",
    position: { lat: 48.7680, long: 2.5150 },
    lines: [demoLine],
  },
  {
    id: "demo-boissy-saint-leger",
    name: "Boissy-Saint-Léger",
    position: { lat: 48.7510, long: 2.5080 },
    lines: [demoLine],
  },
];

function makeDemoJourney(
  id: string,
  currentStopId: string,
  branch: SimpleStop[],
  terminusId: string,
  minutesFromNow: number,
): SimpleJourney {
  const completeRoute = [...demoTrunkStops, ...branch];

  const originIndex = completeRoute.findIndex(
    (stop) => stop.id === currentStopId,
  );

  const stops =
    originIndex >= 0
      ? completeRoute.slice(originIndex)
      : completeRoute;

  const terminusStop =
    completeRoute.find((stop) => stop.id === terminusId) ??
    completeRoute.at(-1);

  const leavesAt = dayjs().add(minutesFromNow, "minute");

  const userStopDeparture: SimpleDeparture = {
    id,
    destination: {
      name: terminusStop?.name ?? "",
      averagePosition: {
        lat: terminusStop?.position.lat ?? 0,
        long: terminusStop?.position.long ?? 0,
      },
    },
    leavesAt,
    arrivesAt: leavesAt,
    journeyCode: id,
    vehicleLength: "LONG",
  };

  return {
    id,
    line: demoLine,
    userStopDeparture,
    stops,
    closedStops: new Set<string>(),
    skippedStops: new Set<string>(),
  };
}


// ============================================================
// DEMO JOURNEYS
// ============================================================

const demoJourneys: SimpleJourney[] = [
  // Active route: Torcy
  makeDemoJourney(
    "NAT8",
    "demo-gare-de-lyon",
    demoUpperBranch,
    "demo-torcy",
    4,
  ),

  // Second train: Chessy
  makeDemoJourney(
    "NAT5",
    "demo-gare-de-lyon",
    demoUpperBranch,
    "demo-marne-la-vallee-chessy",
    12,
  ),

  // Southern branch
  makeDemoJourney(
    "NAT9",
    "demo-gare-de-lyon",
    demoSouthernBranch,
    "demo-boissy-saint-leger",
    7,
  ),

  makeDemoJourney(
    "demo-xa13",
    "demo-gare-de-lyon",
    demoSouthernBranch,
    "demo-boissy-saint-leger",
    16,
  ),
];
// ============================================================
// MAIN
// ============================================================

export async function nextTrainJourneys(
  currentStopId: string,
  lineId: string,
  terminusPosition: Point | undefined,
  previousJourneys: SimpleJourney[],
  fetchCount = 4,
  mockJourneyUrl?: string,
): Promise<SimpleJourney[]> {
  // ==========================================================
  // DEMO
  // ==========================================================

  const importedBundle = getActiveBulbBundle();

  if (importedBundle) {
    const importedJourneys = importedBundle.journeys
      .filter((journey) => journey.stops.some((stop) => stop.id === currentStopId))
      .map((journey) => {
        const origin = journey.stops.findIndex((stop) => stop.id === currentStopId);
        return {
          ...journey,
          stops: journey.stops.slice(origin >= 0 ? origin : 0),
        };
      })
      .slice(0, fetchCount);

    return importedJourneys;
  }

  if (isDemoMode()) {
    console.log("🔥 DEMO MODE ACTIVE");

    const result = demoJourneys
      .filter((journey) =>
        journey.stops.some((stop) => stop.id === currentStopId),
      )
      .slice(
      0,
      fetchCount,
    );

    console.log("🔥 DEMO JOURNEYS:", result);

    return result;
  }

  // ==========================================================
  // ORIGINAL WAGON API
  // ==========================================================

  const departures = await Wagon.departures(
    lineId,
    [currentStopId],
    terminusPosition || {
      lat: 0,
      lon: 0,
    },
  );

  const nearestTerminusBranchHash =
    terminusPosition &&
    nearest(
      terminusPosition,
      departures,
      (d) => ({
        lat: d.destination.averagePosition.lat,
        lon: d.destination.averagePosition.long,
      }),
    )?.branchHash;

  const first = firstUnique(
    fetchCount,
    (x) =>
      x.journeyCode?.slice(0, 2) ||
      x.destination.name,
    departures.filter((x) =>
      nearestTerminusBranchHash
        ? x.branchHash === nearestTerminusBranchHash
        : true,
    ),
  );

  async function getJourney(
    departure: SimpleDeparture,
  ) {
    const needToRefreshFirstJourney =
      dayjs().minute() % 5 === 0;

    const isFirstJourney =
      first.at(0)?.id === departure.id;

    if (
      isFirstJourney &&
      needToRefreshFirstJourney
    ) {
      return Wagon.journey(
        departure.id,
        terminusPosition || {
          lat: 0,
          lon: 0,
        },
        mockJourneyUrl,
      );
    }

    return (
      previousJourneys.find(
        (x) => x.id === departure.id,
      ) ||
      Wagon.journey(
        departure.id,
        terminusPosition || {
          lat: 0,
          lon: 0,
        },
        mockJourneyUrl,
      )
    );
  }

  const result: SimpleJourney[] = [];

  for (
    const [i, departure] of first.entries()
  ) {
    const journey = await getJourney(departure);

    const indexOfOrigin =
      journey.stops.findIndex(
        (x) => x.id === currentStopId,
      );

    const stopsFromOrigin =
      journey.stops.slice(
        indexOfOrigin <= 0 || i === 0
          ? indexOfOrigin
          : indexOfOrigin - 1,
      );

    console.log(
      stopsFromOrigin
        .map((x) => x.name)
        .join(" -> "),
    );

    result.push({
      userStopDeparture: departure,
      ...journey,
      stops: stopsFromOrigin,
    });
  }

  return result;
}