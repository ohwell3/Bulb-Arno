<script lang="ts" setup>
import { usePreferredColorScheme, watchDebounced } from "@vueuse/core";
import { ref, watch } from "vue";
import type { ScreenOption, SelectorBase, SelectorType } from "../screens";
import {
  Wagon,
  ForbiddenError,
  type SimpleLine,
  type SimpleStop,
} from "../services/Wagon";

defineProps<{
  label: string;
  hint?: string;
  authorizedAgencies?: SelectorBase["authorizedAgencies"];
  selectorType: SelectorType;
  stopRoute: ScreenOption | undefined;
}>();

const emit = defineEmits<{
  (e: "update:stopRoutes", value: ScreenOption): void;
}>();

const searchTerms = ref<string>("");
const stops = ref<SimpleStop[]>([]);
const stopModel = ref("");
const stopRouteModel = ref("");
const routesModel = ref<string[]>([]);
const uuid = crypto.randomUUID();
const isLoading = ref(false);
const forbiddenError = ref(false);
const colorScheme = usePreferredColorScheme();

watchDebounced(
  searchTerms,
  async (value) => {
    isLoading.value = true;
    forbiddenError.value = false;
    try {
      stops.value = await Wagon.searchStops(value);
    } catch (e) {
      if (e instanceof ForbiddenError) {
        forbiddenError.value = true;
      }
      stops.value = [];
    } finally {
      isLoading.value = false;
    }
  },
  { debounce: 400 },
);

function getStop(id: string): SimpleStop {
  return stops.value.find((stop) => stop.id === id) as SimpleStop;
}

function getRoute(id: string, stop: SimpleStop): SimpleLine {
  return stop.lines.find((line) => line.id === id) as SimpleLine;
}

function lineModeSvgs(stop: SimpleStop): Set<string> {
  return new Set(
    stop.lines.map((line) => line.pictoSvg).filter((x) => x !== undefined),
  );
}

function colorizeSvg(svg: string, darkColors: Record<string, string>): string {
  if (colorScheme.value !== "dark") {
    return svg;
  }
  let result = svg;
  for (const [color, darkColor] of Object.entries(darkColors)) {
    const regex = new RegExp(color.replace("#", "#?"), "gi");
    result = result.replace(regex, darkColor);
  }
  return result;
}

function linesByMode(lines: SimpleLine[]): {
  picto: string;
  lines: SimpleLine[];
}[] {
  const modes = new Map<string, SimpleLine[]>();
  const sortedLines = lines.sort((a, b) =>
    a.number.padStart(10, "0").localeCompare(b.number.padStart(10, "0")),
  );

  for (const line of sortedLines) {
    const mode = line.pictoSvg;
    if (mode === undefined) {
      continue;
    }
    if (!modes.has(mode)) {
      modes.set(mode, []);
    }
    modes.get(mode)?.push(line);
  }

  return Array.from(modes.entries())
    .sort(
      (a, b) => (a[1].at(0)?.importance ?? 0) - (b[1].at(0)?.importance ?? 0),
    )
    .map(([picto, lines]) => ({
      picto,
      lines,
    }));
}

watch(
  () => stopModel.value,
  (value) => {
    const stop = getStop(value);
    emit("update:stopRoutes", { stop, routes: [], value: undefined });
  },
);

watch(
  () => stopRouteModel.value,
  (value) => {
    const [stopId, routeId] = value.split(" ");
    const stop = getStop(stopId);
    const route = getRoute(routeId, stop);
    emit("update:stopRoutes", { stop, routes: [route], value: undefined });
  },
);

watch(
  () => routesModel.value,
  (value) => {
    const [stopId] = value.at(0)?.split(" ") || [];
    const stop = getStop(stopId);
    const routes = value.map((stopIdRouteId: string) => {
      const [_, routeId] = stopIdRouteId.split(" ");
      return getRoute(routeId, stop);
    });
    emit("update:stopRoutes", { stop, routes, value: undefined });
  },
);
</script>

<template>
  <label>
    <span :aria-busy="isLoading">{{ label }}</span>
    <input type="text" v-model="searchTerms" spellcheck="false" />
    <small v-if="hint"><br />{{ hint }}</small>
  </label>
  <p v-if="forbiddenError"><i>
    Le service n'est disponible que dans les pays couverts par Wagon, dont la
    France, le Canada et d'autres. Ceci peut aussi survenir lors de
    l'utilisation d'un VPN.</i>
  </p>
  <ul>
    <li
      v-for="stop in stops.filter(
        (stop) =>
          authorizedAgencies === 'all' ||
          authorizedAgencies?.includes(stop.id.split('_').at(0) || ''),
      )"
    >
      <label>
        <input
          v-if="selectorType === 'STOP'"
          type="radio"
          :name="uuid"
          v-model="stopModel"
          :value="stop.id"
        />
        <span>{{ stop.name }}</span>
        <div
          v-if="selectorType === 'STOP'"
          class="modePicto"
          v-for="mode in lineModeSvgs(stop)"
          v-html="mode"
        ></div>
      </label>
      <div
        v-if="
          selectorType === 'STOP_AND_ROUTE' ||
          selectorType === 'STOP_AND_ROUTES'
        "
      >
        <ul>
          <li v-for="mode in linesByMode(stop.lines)" :key="mode.picto">
            <div
              class="modePictoRow"
              v-html="
                colorizeSvg(mode.picto, stop.lines.at(0)?.darkColors ?? {})
              "
            ></div>
            <label class="picto" v-for="line in mode.lines" :key="line.id">
              <div
                v-if="line.numberShapeSvg"
                class="lineShape"
                v-html="colorizeSvg(line.numberShapeSvg, line.darkColors)"
              ></div>
              <div v-else>
                <span style="font-style: italic; color: grey">{{
                  line.number
                }}</span>
              </div>
              <input
                v-if="selectorType === 'STOP_AND_ROUTE'"
                type="radio"
                :name="uuid"
                :value="stop.id + ' ' + line.id"
                v-model="stopRouteModel"
              />
              <input
                v-if="selectorType === 'STOP_AND_ROUTES'"
                type="checkbox"
                :name="uuid"
                :value="stop.id + ' ' + line.id"
                v-model="routesModel"
              />
            </label>
          </li>
        </ul>
      </div>
    </li>
  </ul>
</template>

<style scoped>
.lineShape {
  height: 4vh;
}

.modePicto {
  display: inline-block;
  height: 2.6vh;
  margin-left: 0.6vh;
}

.modePictoRow {
  display: inline-block;
  height: 4vh;
  margin-right: 0.6vh;
}

.picto {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  margin-right: 1vh;
  gap: 0.5vh;
}

input[type="radio"] {
  margin-top: 0;
  margin-inline-end: 0;
}
</style>
